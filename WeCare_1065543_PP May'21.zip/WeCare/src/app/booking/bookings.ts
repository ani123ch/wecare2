import { Booking } from "./booking";

export var allBookings: Booking[] = [
    {
        'bookingId': 'B-000',
        'coachId': 'C-101',
        'userId': 'U-101',
        'date': new Date(),
        'slot': '10AM to 11AM'
    }
]