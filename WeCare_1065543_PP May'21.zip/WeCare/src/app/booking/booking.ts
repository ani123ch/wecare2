export class Booking {
    constructor(
        public bookingId: string,
        public coachId: string,
        public userId: string,
        public date: Date,
        public slot: string
    ) { }
}