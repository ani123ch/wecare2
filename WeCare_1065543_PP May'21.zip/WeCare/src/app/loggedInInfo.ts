export var userLoggedIn = '';
export var coachLoggedIn = '';
export var role = '';

export class ChangeUserCoachLoggedData {

    constructor() { }
    
    changeUserLoggedIn(userId: string) {
        userLoggedIn = userId;
        if(userId == '') role = '';
        else role = 'user';
    }

    changeCoachLoggedIn(coachId: string) {
        coachLoggedIn = coachId;
        if(coachId.length == 0) role = '';
        else role = 'coach';
    }

    changeRole() {
        role = '';
    }
}