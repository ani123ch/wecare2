import { Injectable } from '@angular/core';
import { Booking } from './booking/booking';
import { allBookings } from './booking/bookings';

@Injectable({
  providedIn: 'root'
})
export class AppointmentsService {

  constructor() { }

  getAllAppointments(userId: string): Booking[] {
    let bookings: Booking[] = new Array();
    allBookings.forEach(booking => {
      if(booking.userId == userId) {
        var diff = booking.date.getTime() - new Date().getTime();
        var diffDays = Math.ceil(diff / (1000 * 3600 * 24)); 
        if(diffDays >= 0) {
          bookings.push(booking);
        }
      }
    });
    return bookings;
  }

}
