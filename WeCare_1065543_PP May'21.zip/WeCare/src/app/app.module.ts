import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { CoachComponent } from './coach/coach.component';
import { CoachFormComponent } from './coach/coach-form.component';
import { FormsModule } from '@angular/forms';
import { DateofbirthvalidatorDirective } from './dateofbirthvalidator.directive';
import { CoachLoginComponent } from './coach/coach-login.component';
import { UserFormComponent } from './user/user-form.component';
import { UserLoginComponent } from './user/user-login.component';
import { CoachProfile } from './coach/coach-profile.component';
import { UserProfile } from './user/user-profile.component';
import { UserDashboard } from './user/user-dashboard.component';
import { BookingComponent } from './booking/booking.component';
import { UserAppointments } from './user/user-appointments.component';
import { CoachSchedule } from './coach/coach-schedule.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    CoachComponent,
    CoachFormComponent,
    DateofbirthvalidatorDirective,
    CoachLoginComponent,
    UserFormComponent,
    UserLoginComponent,
    CoachProfile,
    UserProfile,
    UserDashboard,
    BookingComponent,
    UserAppointments,
    CoachSchedule
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
