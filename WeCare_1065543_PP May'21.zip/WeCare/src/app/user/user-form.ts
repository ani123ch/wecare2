export class User {
    constructor(
        public userId: string,
        public userName: string,
        public password: string,
        public mobileNumber: string,
        public email: string,
        public dateOfBirth: Date,
        public gender: string,
        public pincode: string,
        public city: string,
        public state: string,
        public country: string
    ) { }
}