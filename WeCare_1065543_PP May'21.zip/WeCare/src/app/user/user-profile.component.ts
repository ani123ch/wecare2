import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { role, userLoggedIn } from "../loggedInInfo";
import { users } from "./user-data";
import { User } from "./user-form";

@Component({
    selector: 'user-profile',
    templateUrl: './user-profile.component.html',
    styleUrls: ['./user-profile.component.css']
})

export class UserProfile {

    //userId: string = 'U-101';
    statusLoggedIn = false
    user = new User('', '', '', '', '', new Date(), '', '', '', '', '')

    constructor(private router: Router) {
        if(role != 'user') {
            this.router.navigateByUrl('home')
            return
        }
        if(userLoggedIn) {
            for(let i = 0; i < users.length; ++i) {
                if(userLoggedIn == users[i].userId) {
                    this.user = users[i];
                    this.statusLoggedIn = true
                    break;
                }
            }
        }
    }
}