import { Component, OnInit } from "@angular/core";
import { Booking } from "../booking/booking";
import { AppointmentsService } from "../appointments.service";
import { Router } from "@angular/router";
import { role, userLoggedIn } from "../loggedInInfo";

@Component({
    selector: 'user-appointments',
    templateUrl: './user-appointments.component.html',
    styleUrls: ['./user-appointments.component.css']
})

export class UserAppointments implements OnInit {

    //userId: string = 'U-101';
    appointments: Booking[] = new Array();
    booking: Booking = new Booking('', '', '', new Date(), '');
    present: Date | undefined;
    given: Date | undefined;

    dateError: string | undefined;

    rescheduleAppointment = false;
    cancelAppointment = false;
    rescheduleSuccess = false;
    cancelSuccess = false;
    cancelBookingId: string = "";

    constructor(
        private appointmentService: AppointmentsService,
        private router: Router) {
        if(role != 'user') {
            this.router.navigateByUrl('home')
        }
    }

    getAppointments() {
        this.appointments = this.appointmentService.getAllAppointments(userLoggedIn);
    }

    ngOnInit() {
        this.getAppointments();
        if(this.appointments.length == 0) console.log('No Appointments Found');
        this.rescheduleAppointment = false;
        this.cancelAppointment = false;
        this.rescheduleSuccess = false;
        this.cancelSuccess = false;
        this.cancelBookingId = "";
    }

    reschedule(bookingId: string) {
        this.rescheduleAppointment = true;
        this.appointments.forEach(app => {
            if(app.bookingId == bookingId) {
                this.booking = app;
            }
        });
    }

    onSubmit() {
        this.appointments.forEach(app => {
            if(app.bookingId == this.booking.bookingId) {
                app.date = this.booking.date;
                app.slot = this.booking.slot;
            }
        });
        this.rescheduleAppointment = false;
        this.rescheduleSuccess = true;
        console.log(this.booking);
        console.log(this.appointments);
    }

    cancel(bookingId: string) {
        this.cancelAppointment = true;
        this.cancelBookingId = bookingId;
    }

    cancelConfirm() {
        this.cancelAppointment = false;
        this.getAppointments();
        for(let i = 0; i < this.appointments.length; ++i) {
            if(this.cancelBookingId == this.appointments[i].bookingId) {
                delete this.appointments[i];
                this.cancelSuccess = true;
            }
        }
        //this.router.navigateByUrl("user-dashboard")
    }

    cancelDecline() {
        this.router.navigateByUrl("user-dashboard")
    }

    validateDate() {
        this.present = new Date(Date.now());
        this.given = new Date(this.booking.date);
        var diff = this.given.getTime() - this.present.getTime();
        var diffDays = Math.ceil(diff / (1000 * 3600 * 24)); 
        if(diffDays > 7 || diffDays <= 0) {
            this.dateError = 'Date should be within future 7 days'
        }
        else {
            this.dateError = undefined;
        }
        console.log('validated');
    }
}