import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { users } from './user-data';
import { User } from './user-form';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent {

  user = new User('', '', '', '', '', new Date(), '', '', '', '', '')

  constructor(private router: Router) { }

  submitted = false;
  userid = 101;
  signup = false;

  present = new Date();
  given=  new Date();
  dateError: string | undefined;

  onSubmit() {
      this.signup = false;
      this.submitted = true;
      ++this.userid;
      this.user.userId = 'U-' + this.userid;
      this.user.dateOfBirth = new Date(this.user.dateOfBirth)
      if(this.dateError) return;
      console.log(this.user);
      users.push(this.user);
      console.log(users);
      this.signup = true;
  }

  validateDate() {
      this.present = new Date(Date.now());
      this.given = new Date(this.user.dateOfBirth);
      console.log(this.present);
      console.log(this.user.dateOfBirth);
      if(this.present.getFullYear() - this.given.getFullYear() < 20 || this.present.getFullYear() - this.given.getFullYear() > 100) {
          this.dateError = 'Date should be 20-100 years old'
      }
      else {
          this.dateError = undefined;
      }
  }

  login() {
    this.router.navigateByUrl("user-login");
  }

}
