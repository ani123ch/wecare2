import { User } from "./user-form";
import { UserLogin } from "./user-login";

export var users: User[] = [
    {
        'userId': 'U-101',
        'userName': 'Funny',
        'password': 'funny789',
        'mobileNumber': '7780557201',
        'email': 'funny@test.com',
        'dateOfBirth': new Date(Date.now()),
        'gender': 'female',
        'pincode': '500088',
        'city': 'Hyderabad',
        'state': 'AP/TS',
        'country': 'India'
    }
]

export var user = new UserLogin('', '')