import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { Booking } from "../booking/booking";
import { allBookings } from "../booking/bookings";
import { coaches } from "../coach/coach-data";
import { role } from "../loggedInInfo";
import { user } from "./user-data";

@Component({
    selector: 'user-dashboard',
    templateUrl: './user-dashboard.component.html',
    styleUrls: ['./user-dashboard.component.css']
})

export class UserDashboard {

    allCoaches = coaches;
    bookingForm = false;
    booking = new Booking('', '', '', new Date(), '');
    userId: string = user.userId;
    bookingid: number = 100;

    present = new Date();
    given = new Date();
    dateError: string | undefined;

    constructor(private router: Router) {
        if(role != 'user') {
            this.router.navigateByUrl('home')
        }
    }

    bookAppointment(coachid: string) {
        this.bookingForm = true;
        this.booking.bookingId = 'B-' + this.bookingid;
        this.booking.coachId = coachid;
        this.booking.userId = this.userId;
    }

    onSubmit() {
        allBookings.push(this.booking);
        this.bookingForm = false;
        this.booking = new Booking('', '', '', new Date(), '');
        console.log(allBookings);
    }

    

    validateDate() {
        this.present = new Date(Date.now());
        this.given = new Date(this.booking.date);
        var diff = this.given.getTime() - this.present.getTime();
        var diffDays = Math.ceil(diff / (1000 * 3600 * 24)); 
        if(diffDays > 7 || diffDays <= 0) {
            this.dateError = 'Date should be within future 7 days'
        }
        else {
            this.dateError = undefined;
        }
    }
}