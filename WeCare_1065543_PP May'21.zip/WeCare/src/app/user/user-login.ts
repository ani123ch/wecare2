export class UserLogin {
    constructor(
        public userId: string,
        public password: string
    ) { }
}