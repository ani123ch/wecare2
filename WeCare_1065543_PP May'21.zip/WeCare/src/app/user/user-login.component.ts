import { Component } from "@angular/core";
import { user as LoggedInUser, users } from "./user-data";
import { ChangeUserCoachLoggedData } from "../loggedInInfo";
import { Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { UserService } from "../user.service";

@Component({
    selector: 'user-login',
    templateUrl: './user-login.component.html',
    styleUrls: ['./user-login.component.css']
})


export class UserLoginComponent {

    submitted = false;
    validUser = false;
    user = LoggedInUser;

    changeUserData = new ChangeUserCoachLoggedData();

    constructor(private router: Router) { }

    onSubmit() {
        this.submitted = true;
        let i = 0;
        console.log(this.user);
        let userValidity;

        /*this.userService.isValidUser(this.user)
            .subscribe(hero => userValidity = hero);

        console.log(userValidity);
        if(userValidity == "Login successfull") {
            this.validUser = true;
            this.changeUserData.changeUserLoggedIn(users[i].userId);
            this.router.navigateByUrl('/user-dashboard');
        }
        else {
            this.validUser = false;
        }*/
        for(; i < users.length; ++i) {
            if(users[i].userId === this.user.userId && users[i].password === this.user.password) {
                this.validUser = true;
                this.changeUserData.changeUserLoggedIn(users[i].userId);
                this.router.navigateByUrl('/user-dashboard');
                break;
            } else if(users[i].userId === this.user.userId) {
                this.validUser = false;
                break;
            }
        }
        if(i == users.length) this.validUser = false;
        console.log(this.validUser);
    }
}