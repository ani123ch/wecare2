import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { Booking } from "../booking/booking";
import { coachLoggedIn, role } from "../loggedInInfo";
import { ScheduleService } from "../schedule.service";


@Component({
    selector: 'coach-schedule',
    templateUrl: './coach-schedule.component.html',
    styleUrls: ['./coach-schedule.component.css']
})

export class CoachSchedule {

    //coachId: string = 'C-101';
    schedule: Booking[] | undefined;

    constructor(private router: Router,
        private scheduleService: ScheduleService) { 
            if(role != "coach") {
                this.router.navigateByUrl("home")
            }
    }

    getSchedule() {
        this.schedule = this.scheduleService.getSchedule(coachLoggedIn);
    }

    ngOnInit() {
        this.getSchedule();
    }
}