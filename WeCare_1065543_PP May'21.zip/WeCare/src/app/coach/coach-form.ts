export class Coach {
    constructor(
        public coachId: string,
        public coachName: string,
        public password: string,
        public dateOfBirth: Date,
        public gender: string,
        public mobileNumber: string,
        public speciality: string
    ) { }
}