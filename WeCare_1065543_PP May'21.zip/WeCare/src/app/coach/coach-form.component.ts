import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { coaches } from "./coach-data";
import { Coach } from "./coach-form";

@Component({
    selector: 'app-coach-form',
    templateUrl: './coach-form.component.html',
    styleUrls: ['./coach-form.component.css']
})

export class CoachFormComponent {

    coach = new Coach('', '', '', new Date('1998-07-09'), '', '', '');
    submitted = false;
    coachid = 101;
    signup = false;

    present = new Date();
    given=  new Date();
    dateError: string | undefined;

    constructor(private router: Router) { }

    onSubmit() {
        this.signup = false;
        this.submitted = true;
        ++this.coachid;
        this.coach.coachId = 'C-' + this.coachid;
        //++this.coachid;
        if(this.dateError) return;
        console.log(this.coach);
        coaches.push(this.coach);
        console.log(coaches);
        this.signup = true;
    }

    validateDate() {
        this.present = new Date(Date.now());
        this.given = new Date(this.coach.dateOfBirth);
        console.log(this.present);
        console.log(this.coach.dateOfBirth);
        if(this.present.getFullYear() - this.given.getFullYear() < 20 || this.present.getFullYear() - this.given.getFullYear() > 100) {
            this.dateError = 'Date should be 20-100 years old'
        }
        else {
            this.dateError = undefined;
        }
    }

    login() {
        this.router.navigateByUrl("coach-login")
    }
}