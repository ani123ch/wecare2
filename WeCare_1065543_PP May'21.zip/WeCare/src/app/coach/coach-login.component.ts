import { Component } from "@angular/core";
import { coaches } from "./coach-data";
import { CoachLogin } from "./coach-login";
import { ChangeUserCoachLoggedData } from "../loggedInInfo";
import { Router } from "@angular/router";

@Component({
    selector: 'coach-login',
    templateUrl: './coach-login.component.html',
    styleUrls: ['./coach-login.component.css']
})

export class CoachLoginComponent {

    coach = new CoachLogin('', '');
    submitted = false;
    validUser = false;

    changeCoachData = new ChangeUserCoachLoggedData();

    constructor(private router: Router) { }

    onSubmit() {
        this.submitted = true;
        let i = 0;
        for(; i < coaches.length; ++i) {
            if(coaches[i].coachId == this.coach.coachId && coaches[i].password == this.coach.password) {
                this.validUser = true;
                this.changeCoachData.changeCoachLoggedIn(coaches[i].coachId);
                this.router.navigateByUrl('coach-dashboard')
                break;
            } else if(coaches[i].coachId == this.coach.coachId) {
                this.validUser = false;
                break;
            }
        }
        if(i == coaches.length) this.validUser = false;
    }
}