import { Component } from "@angular/core";
import { Router } from "@angular/router";
import { coachLoggedIn, role } from "../loggedInInfo";
import { coaches } from "./coach-data";
import { Coach } from "./coach-form";

@Component({
    selector: 'coach-profile',
    templateUrl: './coach-profile.component.html',
    styleUrls: ['./coach-profile.component.css']
})

export class CoachProfile {

    logged = false
    coach = new Coach('', '', '', new Date('1998-07-09'), '', '', '');

    constructor(private router: Router) {
        if(role != "coach") {
            this.router.navigateByUrl("home")
            return
        }
        if(coachLoggedIn) {
            for(let i = 0; i < coaches.length; ++i) {
                if(coachLoggedIn == coaches[i].coachId) {
                    this.coach = coaches[i];
                    this.coach.dateOfBirth = new Date(this.coach.dateOfBirth);
                    this.logged = true
                    break;
                }
            }
        }
    }
}