import { Coach } from "./coach-form";

export var coaches: Coach[] = [
    {
        'coachId': 'C-100',
        'coachName': 'funny',
        'password': 'funny789',
        'dateOfBirth': new Date('07-09-1998'),
        'gender': 'Female',
        'mobileNumber': '7093848710',
        'speciality': 'anxiety'
    },
    {
        'coachId': 'C-101',
        'coachName': 'smiley',
        'password': 'smiley789',
        'dateOfBirth': new Date('07-09-1998'),
        'gender': 'Female',
        'mobileNumber': '7780557201',
        'speciality': 'confidence'
    }
]