export class CoachLogin {
    constructor(
        public coachId: string,
        public password: string
    ) { }
}