import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ChangeUserCoachLoggedData, role, userLoggedIn } from './loggedInInfo';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'WeCare';
  logout = false;
  uProfile = false;
  cProfile =false;

  changeLoggedIn = new ChangeUserCoachLoggedData();

  constructor(private router: Router) {
    router.events.subscribe((val) => {
      this.logout = false
      this.uProfile = false
      this.cProfile = false

      if (role == "user" && (router.url == "/user-dashboard" || router.url == "/user-profile" || router.url=="/user-appointments")) {
        console.log("Role " + role);
        this.logout = true
        this.uProfile = true
        this.cProfile = false
      }
      else if(role == 'coach' && (router.url == "/coach-dashboard"|| router.url=="/coach-profile")) {
        this.logout = true
        this.uProfile =false
        this.cProfile = true
      }
      else {
        this.uProfile = false
        this.logout = false
        this.cProfile = false
      }
    })
  }

  logoutFn(){
    //localStorage.removeItem('userId')
    this.uProfile = false;
    this.logout = false;
    this.cProfile = false;
    this.changeLoggedIn.changeCoachLoggedIn('');
    this.changeLoggedIn.changeUserLoggedIn('');
  }

}
