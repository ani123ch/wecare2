import { DatePipe, formatDate } from '@angular/common';
import { Directive } from '@angular/core';
import { AbstractControl, FormControl, NG_VALIDATORS, RequiredValidator, ValidationErrors, Validator } from '@angular/forms';

@Directive({
  selector: '[dateValidator]'
})
export class DateofbirthvalidatorDirective implements Validator {

  present = new Date();
  given = new Date();

  constructor() { }

  validate(control: FormControl): { [key: string] : any} | null {
    this.present = new Date(Date.now());
    this.given = new Date(control.value());
    console.log(this.present);
    console.log(this.given);
    if(this.present.getFullYear() - this.given.getFullYear() < 20 || this.present.getFullYear() - this.given.getFullYear() > 100) {
      return { 'dateOfBirthInvalid': 'Date Of birth is invalid' };
    }
    return null;
  }

}
