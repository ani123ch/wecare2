import { Injectable } from '@angular/core';
import { HttpClient, HttpHandler, HttpHeaders } from '@angular/common/http';
import { UserLogin } from './user/user-login';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class UserService {

  constructor(private http: HttpClient) { }

  isValidUser(user: UserLogin) : Observable<any> {
    const options = new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': 'http://localhost:8000/' });
    console.log(this.http.post('http://localhost:8000/login', user, { }).pipe(map((res: Object) => Object(res).json())))
    return this.http.post('http://localhost:8000/login', user).pipe(map((res: Object) => Object(res).json()))
  }
}
