import { DateofbirthvalidatorDirective } from './dateofbirthvalidator.directive';

describe('DateofbirthvalidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new DateofbirthvalidatorDirective();
    expect(directive).toBeTruthy();
  });
});
