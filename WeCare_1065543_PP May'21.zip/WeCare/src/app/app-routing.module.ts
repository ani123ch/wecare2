import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { BookingComponent } from './booking/booking.component';
import { CoachFormComponent } from './coach/coach-form.component';
import { CoachLoginComponent } from './coach/coach-login.component';
import { CoachProfile } from './coach/coach-profile.component';
import { CoachSchedule } from './coach/coach-schedule.component';
import { HomeComponent } from './home/home.component';
import { UserAppointments } from './user/user-appointments.component';
import { UserDashboard } from './user/user-dashboard.component';
import { UserFormComponent } from './user/user-form.component';
import { UserLoginComponent } from './user/user-login.component';
import { UserProfile } from './user/user-profile.component';

const routes: Routes = [
    { path: 'coach-signup', component: CoachFormComponent },
    { path: 'coach-login', component: CoachLoginComponent},
    { path: 'user-signup', component: UserFormComponent },
    { path: 'user-login', component: UserLoginComponent },
    { path: 'coach-dashboard', component: CoachSchedule },
    { path: 'user-dashboard', component: UserDashboard },
    { path: 'user-appointments', component: UserAppointments },
    { path: 'user-profile', component: UserProfile },
    { path: 'coach-profile', component: CoachProfile },
    { path: 'book-appointment', component: BookingComponent },
    { path: 'home', component: HomeComponent },
    { path: '', redirectTo: '/home', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
